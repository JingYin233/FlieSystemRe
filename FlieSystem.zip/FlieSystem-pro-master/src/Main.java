import controller.MainController;

/**
 * 
 * @author Tom Hu
 * 
 */
public class Main {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainController mainController = new MainController();
		mainController.showMainView();

	}
}
